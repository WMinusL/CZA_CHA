#define DLL_EXTRA_PATH "c:\\program files\\python37"
#define NO_PYTHON_WARNINGS 0
#define PYTHON_HOME_PATH "C:\\Program Files\\Python37"
#define SYSFLAG_BYTES_WARNING 0
#define SYSFLAG_NO_RANDOMIZATION 0
#define SYSFLAG_NO_SITE 0
#define SYSFLAG_OPTIMIZE 0
#define SYSFLAG_UTF8 0
#define SYSFLAG_VERBOSE 0
