Name：城市名
Lat：纬度
South：选0北半球，选1南半球

by WMinusL 
License:MIT License